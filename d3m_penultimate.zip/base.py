import abc


class PrimitiveBase(abc.ABCMeta):
    """
    A base class for all TA1 primitives.
    """

    # __metaclass__ = abc.ABCMeta
